폴더를 복사한 후 스킨을 수정하십시오.
After copying the folder, modify the skin.